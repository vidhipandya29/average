
/**
 * Write a description of class Average here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Average
{
    public static void main (String args [])
    {
        new Average ();
    }
    
    
    public Average ()
    {
        System.out.println ("AVERAGE");
        System.out.println ("Enter the percentage earned on each test.");
        double first = IBIO.inputInt ("\nWhat is student #1's mark? ");
        double second = IBIO.inputInt ("What is student #2's mark? ");
        double third = IBIO.inputInt ("What is student #3's mark? ");
        double fourth = IBIO.inputInt ("What is student #4's mark? ");
        double fifth = IBIO.inputInt ("What is student #5's mark? ");
        double sixth = IBIO.inputInt ("What is student #6's mark? ");
        
        double average = (first + second + third + fourth + fifth + sixth)/(6);
        
        System.out.println ("\nThere are six students in the class.");
        System.out.println ("The average mark was " +average+" %");
    }
}    